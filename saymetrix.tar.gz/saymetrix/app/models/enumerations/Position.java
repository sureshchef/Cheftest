package models.enumerations;

public enum Position {
    INDOOR, OUTDOOR, ONTHEMOVE
}
