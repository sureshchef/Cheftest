package models.enumerations;

public enum Frequency {

    OFTEN, ONCE, SELDOM, ALWAYS, RARE
}
