default['apt']['cacher-client']['restrict_environment'] = false
default['apt']['cacher_port'] = 3142
default['apt']['key_proxy'] = ''
default['apt']['caching_server'] = false
