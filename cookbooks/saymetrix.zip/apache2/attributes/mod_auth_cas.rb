default['apache']['mod_auth_cas']['from_source'] = false
default['apache']['mod_auth_cas']['source_revision'] = "v1.0.8.1"
