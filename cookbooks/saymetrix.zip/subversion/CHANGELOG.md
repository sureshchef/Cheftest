## v1.0.2:

* Resolves foodcritic warnings
* [COOK-1513] - support SUSE SLES

## v1.0.0:

* [COOK-810] - add Windows platform support

## v0.8.3:

* Current public release
