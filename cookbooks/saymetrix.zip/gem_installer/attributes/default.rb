default[:gem_installer][:gems] = {}
default[:gem_installer][:chef_gems] = {}
