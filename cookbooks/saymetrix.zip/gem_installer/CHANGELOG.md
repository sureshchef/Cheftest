Changelog
=========

v0.1.2
------

* Add support for chef_gem
* Only allow Hashes

v0.1.1
------

* Removes builtin BagConfig support
* Allows gems to be specified in Array or Hash form
