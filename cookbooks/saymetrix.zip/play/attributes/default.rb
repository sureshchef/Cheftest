default[:play2][:version]                   = "2.1.1"


default[:play2][:path][:prefix]				= "/srv"
