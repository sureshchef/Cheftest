
default['fastflow']['url'] = 'http://sourceforge.net/projects/mc-fastflow/files/latest/download?source=dlp'
default["fastflow"]["dir"] = "/opt/fastflow"
default['build_essential']['compiletime'] = false

default['ZMQ']['ZMQ_HOME'] = "/usr/local"
default['LD_LIBRARY']['LD_LIBRARY_PATH'] = "usr/local/lib"
