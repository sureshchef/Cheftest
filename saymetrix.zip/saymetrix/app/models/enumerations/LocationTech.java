package models.enumerations;

public enum LocationTech {
    GPS,MANUAL,NETWORK
}
