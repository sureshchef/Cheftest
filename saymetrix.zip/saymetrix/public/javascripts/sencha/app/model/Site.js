Ext.define('SF.model.Site', {
    extend: 'Ext.data.Model',
    fields: [
        'id',
        'key',
        'latitude',
        'longitude',
        'street_address',
        'technologies'
    ]
});


