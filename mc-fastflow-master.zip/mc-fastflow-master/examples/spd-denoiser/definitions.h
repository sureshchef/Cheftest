#ifndef _SPD_DEFINITIONS_H_
#define _SPD_DEFINITIONS_H_

#define ALIGNMENT 64

//typedef unsigned char grayscale;
typedef unsigned int bmp_size_t;
typedef unsigned char grayscale;

#define SALT 0
#define PEPPER 255

typedef long grayscale_ctrl;
#endif
